package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
	"strings"

	"github.com/google/uuid"
)

var (
	db *gorm.DB
)

type Userinfo struct {
	Name     	string 	`json:"name"`
	Password 	string 	`json:"password"`
	Email    	string 	`json:"email"`
	Mobile		string 	`json:"mobile"`
}

type TbUser struct {
	//ID.NAME.PASSWORD.EMAIL.MOBILE
	Id 		 	string 	`gorm:"type:varchar(64)" json:"id"`
	Name     	string 	`gorm:"type:varchar(64)" json:"name"`
	Password 	string 	`gorm:"type:varchar(128)" json:"password"`
	Email    	string 	`gorm:"type:varchar(128)" json:"email"`
	Mobile		string 	`gorm:"type:varchar(64)" json:"mobile"`
}

func (*TbUser) TableName() string {
	return "tb_user"
}

func main() {
	// 连接数据库 root:666666@(121.196.20.196:3306)/my_test_db?charset=utf8
	var err error
	db, err = gorm.Open("mysql", "jspi:jspteami!1@(112.175.184.59:21)/my_test_db?charset=utf8mb4&parseTime=True&loc=Local")

	if err != nil {
		fmt.Printf("gorm is err : %s\n", err.Error())
		return
	}
	defer db.Close()

	// 自动迁移模式
	db.AutoMigrate(&TbUser{})

	// 开启api服务
	r := gin.Default()
	v1 := r.Group("/api/v1")
	{
		v1.POST("/register", Register)
	}

	r.Run(":9370")
}


func Register(c *gin.Context) {
	var user Userinfo
	if err := c.ShouldBind(&user); err != nil {
		c.JSON(200, gin.H{
			"code":     500,
			"message": err.Error(),
		})
		return
	}
	fmt.Println(user)
	u := TbUser{}
	err := db.Table("tb_user").Where("name = ?", user.Name).First(&u).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		fmt.Printf("Register First is err : %s\n", err.Error())
		c.JSON(500, gin.H{
			"code":     500,
			"message": "查询用户出错",
		})
		return
	}
	if u.Id != "" {
		c.JSON(500, gin.H{
			"code":     500,
			"message": "用户名已存在",
		})
		return
	}
	newUser := &TbUser{
		Id:			NewId(),
		Name:   	user.Name,
		Password: 	user.Password,
		Email:  	user.Email,
		Mobile:  	user.Mobile,
	}
	err = db.Table("tb_user").Create(newUser).Error
	if err != nil {
		fmt.Printf("Register Create is err : %s\n", err.Error())
		c.JSON(500, gin.H{
			"code":     500,
			"message": "注册失败",
		})
		return
	}
	c.JSON(200, gin.H{
		"code":     200,
		"data": 	newUser,
		"message": "注册成功",
	})
	return
}

func NewId() string {
	id := uuid.New().String()
	id = strings.Replace(id, "-", "", -1)
	return id
}